# encoder-decoder
An encoder and decoder

Made in Node JS

Charecters Included So Far: Space, Period, Colon, Comma, Exclamation Mark, and the lower case alphabet

Size of File: 1.67 KB

# Requirements

Node JS: https://nodejs.org/en/download/

Download Avaliabe for Windows, Mac and Linux

# How To Run

Open your command prompt

Clone This Repo

In Your Command Prompt Type `node "encoder and decoder.js"`

And When You Want To Exit The Program Press:
- Windows & Linux: CTRL + C
- Mac: CMD + C
  
