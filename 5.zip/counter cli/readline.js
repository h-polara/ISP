// import readline

readline = require("readline").createInterface({
    input: process.stdin,
    output: process.stdout
})

const chalk = require("chalk");

// Variables

var counterTMP;
var counter = 0

// Functions

function counterUpdate(c, cfunction) {
    if (cfunction === 0) {
        counterTMP = c + 1;
    } else if (cfunction === 1) {
        counterTMP = c - 1;
    } else if (cfunction === 2) {
        counterTMP = 0;
        c = 0;
    }
    return counterTMP;
}

function updateScreen(c) {
    console.clear()
    if (c < 0) {
        console.log(chalk.red(chalk.bold(c)))
    } else if (c === 0) {
        console.log(chalk.whiteBright(chalk.bold(c)))
    } else if (c > 0) {
        console.log(chalk.greenBright(chalk.bold(c)))
    }
    readline.question("\nCommand > ", command => {
        if (command === "H" || command === "h" || command === "help" || command === "Help") {
            console.log("I - Increases the counter");
            console.log("D - Decreases the counter");
            console.log("R - Resets the counter");
            console.log("E - Exit");
            readline.question("Press Enter to Continue", none => {
                updateScreen(counter)
            });
        } else if(command === "I" || command === "i") {
            counter = counterUpdate(c, 0)
            updateScreen(counter)
        } else if(command === "D" || command === "d") {
            counter = counterUpdate(c, 1)
            updateScreen(counter)
        } else if(command === "R" || command === "r") {
            counter = counterUpdate(c, 2)
            updateScreen(counter)
        } else if(command === "E" || command === "e") {
            console.clear();
            process.exit(1);
        } else if(command === " ") {
            console.warn("Command Not Found")
            readline.question("Press Enter to Continue", none => {
                updateScreen(counter)
            });
        } else {
            console.warn("Command Not Found : Type H for help")
            readline.question("Press Enter to Continue", none => {
                updateScreen(counter)
            });
        }
    })
}

updateScreen(counter)