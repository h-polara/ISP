// import readline

var inquirer = require("inquirer")

readline = require("readline").createInterface({
    input: process.stdin,
    output: process.stdout
})

const chalk = require("chalk");

// Variables

var counterTMP;
var counter = 0
var idefault = "Increase";

// Functions

function counterUpdate(c, cfunction) {
    if (cfunction === 0) {
        counterTMP = c + 1;
    } else if (cfunction === 1) {
        counterTMP = c - 1;
    } else if (cfunction === 2) {
        counterTMP = 0;
        c = 0;
    }
    return counterTMP;
}

function updateScreen(c) {
    console.clear()
    if (c < 0) {
        console.log(chalk.red(chalk.bold("      " + c)))
    } else if (c === 0) {
        console.log(chalk.whiteBright(chalk.bold("      " + c)))
    } else if (c > 0) {
        console.log(chalk.greenBright(chalk.bold("      " + c)))
    }
    inquirer.prompt([
        {
            type: 'list',
            name: 'command',
            message: 'Command',
            choices: ['Increase', 'Decrease', 'Reset', 'Exit'],
            default: idefault
        }
    ]).then(answers => {
        if(answers.command === "Increase") {
            counter = counterUpdate(c, 0)
            idefault = "Increase";
            updateScreen(counter)
        } else if(answers.command === "Decrease") {
            counter = counterUpdate(c, 1)
            idefault = "Decrease";
            updateScreen(counter)
        } else if(answers.command === "Reset") {
            counter = counterUpdate(c, 2)
            idefault = "Reset";
            updateScreen(counter)
        } else if(answers.command === "Exit") {
            console.clear();
            process.exit(1);
        }
    }).catch((error) => {
        if (error.isTtyError) {
          console.log("couldn't be rendered in the current environment")
        } else {
          console.log(error)
        }
    })
}

updateScreen(counter)